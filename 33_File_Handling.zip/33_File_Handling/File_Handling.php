<?php 
readfile("tex.txt");

 ?>